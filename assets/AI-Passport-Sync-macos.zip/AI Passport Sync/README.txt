AI Passport Sync for macOS

1. Open Terminal.
2. Run `cd `, then drag this "AI Passport Sync" folder into Terminal and press
   Return. Run `bash start.sh`.
3. The first launch installs the bundled Node.js/Python
   dependencies when needed.
4. If needed, complete the lark-cli authorization opened by the launcher.
   Startup continues automatically after authorization succeeds.
5. Allow Bluetooth access when macOS asks, then keep the AI Passport in its
   Bluetooth pairing screen.

Requirements: macOS, Node.js 20 or later, Python 3, and lark-cli.
The script runs only on this Mac because it reads this Mac's lark-cli identity and
uses this Mac's Bluetooth hardware. No credentials are packaged in this archive.
